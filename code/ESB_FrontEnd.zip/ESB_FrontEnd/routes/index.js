const createError = require('http-errors');
const express = require('express');
const router = express.Router();
const path = require('path');
const convert = require('xml-js');
const config = require('../globals.json');

/* GET home page. 
 * Will, if successful, retrieve the page with the usage instructions
*/
router.get('/', function(req, res, next) {
  console.log("serving: " + path.join(__dirname, '/../public', 'index.html'));
  res.sendFile(path.join(__dirname, '/../public', 'index.html'));
});

/*
 * Publish message (POST).
 */
router.post('/:routingkey', function(req, res) {
  // Check to see if user was found and route accordingly - requirement in article:
  // - It should require authentication and route messages according to the publishing user
  if (!req.ex) {
    err = createError(401);
    res.locals.message = err.message;
    res.locals.error = req.app.get('env') === 'development' ? err : {};
    res.status(err.status || 500);
    res.json({ success: false });
  } else {
    const key = req.params.routingkey;
    // Create and set a correlation Id 
    // This will give you both a correlation_id property, as well as a "correlationId" headers entry.
    const rheaders = {"headers": {"correlationId" : uuid()}};
    rheaders['correlationId'] = uuid();
    console.log("Posting to exchange: " + req.ex + " with routing key: " + key);
    // console.log("RabbitMQ headers: " + JSON.stringify(rheaders));

    var content = Buffer.from(req.body);
    var contenttype = req.headers["content-type"];
    if(contenttype.indexOf(";")!= -1){contenttype = contenttype.substring(0,contenttype.indexOf(";"))}
    // Example of xml to json conversion - requirement in article:
    // you might choose to convert to i.e. json so that all published messages are same format
    contenttype = contenttype.toLowerCase();
    if(contenttype=="application/xml"){
      console.log("xml!");
      const xml = req.rawBody;
      console.log(req.rawBody);
      try {
        content = new Buffer(convert.xml2json(xml, {compact: true, spaces: 4}));
      } catch(err) {
        result = err.message;
        console.log(result);
      }
    }
    // Publish to RabbitMQ exchange, as configured on user
    amqpConn.createChannel(function(err, ch) {
      ch.assertExchange(req.ex, 'topic', {durable: config.amqp.exchange_durable});
      ch.publish(req.ex, key, content, rheaders);
    });
    res.json({ success: true });
  }
});

function uuid() {
  d = new Date();
  return 'A' + d.getTime();
}

module.exports = router;