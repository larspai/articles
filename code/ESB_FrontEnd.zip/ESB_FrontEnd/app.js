const createError = require('http-errors');
const express = require('express');
const path = require('path');
const cookieParser = require('cookie-parser');
const bodyParser = require('body-parser');
const config = require('./globals.json');


const DatabaseService = require('./services/database-service');
const databaseService = new DatabaseService();
const indexRouter = require('./routes/index');

var users = [];
databaseService.getUsers().then((usrs) => { users = usrs; }); // get users from db
const app = express();

const amqp = require('amqplib/callback_api');
amqpConn = null;

const options = {
  type: '*/*',
  verify: function(req, res, buf, encoding) {
      req.rawBody = buf.toString();
  }
};
app.use(bodyParser.text(options));

app.use(function(req, res, next) {
  // This user authentication is simplistic
  // parse login and password from headers
  const b64auth = (req.headers.authorization || '').split(' ')[1] || '';
  const strauth = Buffer.from(b64auth, 'base64').toString();
  const splitIndex = strauth.indexOf(':');
  const login = strauth.substring(0, splitIndex);
  const password = strauth.substring(splitIndex + 1);
  // check if user exists
  req.ex = null;
  users.forEach(lookupUser);
  // If the user was not found in the cache, reload it and check again - requirement in article:
  // - It should not need to be redeployed to support new publishers
  if(!req.ex){
    databaseService.getUsers().then((usrs) => { users = usrs; }).then(users.forEach(lookupUser));
  }
  next();
  function lookupUser(value, index, array) {
    if (login && password && login === value.name && password === value.password) {
      req.ex = value.exchange;
    } 
  }
});

app.use('/', indexRouter);

// Start the AMQP (RabbitMQ) connection
amqpConnect();

// catch 404 and forward to error handler
app.use(function(req, res, next) {
  next(createError(404));
});

// error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  // console.log("Error occurred: " + err.status);
  console.log("Error occurred: " + err);
  res.sendFile(path.join(__dirname, './public', 'error.html'));
});

function amqpConnect() {
  amqp.connect(config.amqp.AMQP_URI + "?heartbeat=60", function(err, conn) {
    if (err) {
      console.error("[RMQ error]", err.message);
      return setTimeout(amqpConnect, 1000);
    }
    conn.on("error", function(err) {
      if (err.message !== "Connection closing") {
        console.error("[RMQ] conn error: ", err.message);
      }
    });
    conn.on("close", function() {
      console.error("[RMQ] Reconnecting");
      return setTimeout(amqpConnect, 1000);
    });
    console.log("[RMQ] Connected");
    amqpConn = conn;
  });
}

module.exports = app;
