const monk = require('monk');
const config = require('../globals.json');
const db = monk(config.mongo.MONGO_URI);
db.then(() => {
    console.log('Connected correctly to server')
  });
// const db = monk('mongodb://slmongolab:mongolabsl01@ds055895.mongolab.com:55895/statuslogio');

class DatabaseService {

    /*
    * Get (GET) users
    */
    async getUsers() {
        try {
            var users = db.get('users');
            return users.find();    
        } catch (error) {
            console.log(error);
            return undefined;
        }
    };

}

    
module.exports = DatabaseService;