package main

import (
	"log"
	os "os"

	"github.com/streadway/amqp"
)

func failOnError(err error, msg string) {
	if err != nil {
		log.Fatalf("%s: %s", msg, err)
	}
}

func main() {
	conn, err := amqp.Dial("amqp://guest:guest@localhost:5672/")
	failOnError(err, "Failed to connect to RabbitMQ")
	defer conn.Close()

	ch, err := conn.Channel()
	failOnError(err, "Failed to open a channel")
	defer ch.Close()

	err = ch.ExchangeDeclare(
		os.Args[1], 					// name
		"headers",    				// type
		false,        			// durable
		false,        		// auto-deleted
		false,        			// internal
		false,        			// no-wait
		nil,          				// arguments
	)
	failOnError(err, "Failed to declare exchange")

	q, err := ch.QueueDeclare(
		os.Args[2],    					// name
		false, 					// durable
		false, 				// delete when unused
		true,  				// exclusive
		false, 					// no-wait
		nil,  		 				// arguments
	)
	failOnError(err, "Failed to declare queue")

	log.Printf("Binding queue %s to exchange %s with routing key %s", q.Name, os.Args[1], os.Args[3])
	err = ch.QueueBind(
		q.Name,       					// queue name
		os.Args[3],						// routing key
		os.Args[1], 					// exchange
		false,
		nil)
	failOnError(err, "Failed to bind queue")

	msgs, err := ch.Consume(
		q.Name, 						// queue
		"Go_Consumer",  		// consumer
		true,   				// auto ack
		false,  				// exclusive
		false,  				// no local
		false,  					// no wait
		nil,    					// args
	)
	failOnError(err, "Failed to register consumer")

	forever := make(chan bool)

	go func() {
		for d := range msgs {
			// This is where the transformation code/callout should go
			log.Printf(" [x] %s", d.Body)
		}
	}()

	log.Printf(" [*] Waiting for Messages. To exit: press CTRL+C")
	<-forever
}
