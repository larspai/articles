package main

import (
    "fmt"
    "log"
    "net/http"
    "io"
  	"io/ioutil"

    "github.com/streadway/amqp"
    "github.com/gorilla/mux"
)

var conn amqp.Connection
var ch amqp.Channel
var err error

func failOnError(err error, msg string) {
	if err != nil {
		log.Fatalf("%s: %s", msg, err)
	}
}

func main() {
  router := mux.NewRouter().StrictSlash(true)
  router.HandleFunc("/", Index)
  router.HandleFunc("/{exchange}", Exchange)
  router.HandleFunc("/{exchange}/{routingkey}", ExchangeAndRoutingkey)

  log.Fatal(http.ListenAndServe(":8080", router))

}

func Index(w http.ResponseWriter, r *http.Request) {
    fmt.Fprintln(w, "Welcome!")
}

func Exchange(w http.ResponseWriter, r *http.Request) {
  vars := mux.Vars(r)
  exchange := vars["exchange"]
  fmt.Fprintln(w, "Exchange:", exchange)
}

func ExchangeAndRoutingkey(w http.ResponseWriter, r *http.Request) {
  vars := mux.Vars(r)
  exchange := vars["exchange"]
  routingkey := vars["routingkey"]
  body, err := ioutil.ReadAll(io.LimitReader(r.Body, 1048576))
  if err != nil {
    panic(err)
  }
  if err := r.Body.Close(); err != nil {
    panic(err)
  }
  SendToRMQ(exchange, routingkey, body)
}

func SendToRMQ(e string, rk string, b []byte) {
  conn, err := amqp.Dial("amqp://guest:guest@localhost:5672/")
  failOnError(err, "Failed to connect to RabbitMQ")
  defer conn.Close()

  ch, err := conn.Channel()
  failOnError(err, "Failed to open a channel")
  defer ch.Close()

  err = ch.ExchangeDeclare(
		e, 	// name
		"headers",    // type
		false,        // durable
		false,        // auto-deleted
		false,        // internal
		false,        // no-wait
		nil,          // arguments
	)
	failOnError(err, "Failed to declare exchange")

  // Reliable publisher confirms require confirm.select support from the
	// connection.
	log.Printf("enabling publishing confirms.")
	err = ch.Confirm(false)
		failOnError(err, "Channel could not be put into confirm mode")

	confirms := ch.NotifyPublish(make(chan amqp.Confirmation, 1))

	defer confirmOne(confirms)

	log.Printf("declared Exchange, publishing %dB body (%q)", len(b), b)
	var args = make(amqp.Table)
  args["message-type"] = rk
  err = ch.Publish(
		e,   // publish to an exchange
		"", // routing to 0 or more queues
		false,      // mandatory
		false,      // immediate
		amqp.Publishing{
			Headers:         args,
			ContentType:     "text/plain",
			ContentEncoding: "",
			Body:            b,
			DeliveryMode:    amqp.Transient, // 1=non-persistent, 2=persistent
			Priority:        0,              // 0-9
			// a bunch of application/implementation-specific fields
		},
	)
	failOnError(err, "Exchange Publish")
}

// One would typically keep a channel of publishings, a sequence number, and a
// set of unacknowledged sequence numbers and loop until the publishing channel
// is closed.
func confirmOne(confirms <-chan amqp.Confirmation) {
	log.Printf("waiting for confirmation of one publishing")

	if confirmed := <-confirms; confirmed.Ack {
		log.Printf("confirmed delivery with delivery tag: %d", confirmed.DeliveryTag)
	} else {
		log.Printf("failed delivery of delivery tag: %d", confirmed.DeliveryTag)
	}
}
