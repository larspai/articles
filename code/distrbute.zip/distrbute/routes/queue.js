var router = express.Router();
/* amqp Example */
var amqp = require('amqplib/callback_api');
/*
 * Update (POST) queue.
 */
router.post('/:queue', function(req, res) {
  d = new Date();
  if (req.headers.correlation_id==null){var instring = "C"+d.getTime();}else{
  var instring = req.headers.correlation_id.toString();}
  var rheaders = new Object();
  rheaders['correlationId'] = instring;
  rheaders['messageId'] = 'A' + d.getTime();
  console.log(rheaders);

  amqpConn.createChannel(function(err, ch) {
    var q = req.params.queue;
    var msg = req.body.document;

    ch.assertQueue(q, {durable: config.amqp.queue_durable});
    // Note: on Node 6 Buffer.from(msg) should be used
//    ch.sendToQueue(q, new Buffer(msg));
    ch.sendToQueue(q, req.rawBody, rheaders);
    console.log(" [x] Sent %s", req.rawBody);
  });
	res.json({ thishappened: 'POST queue executed'});
});

/*
 * Update (GET) queue.
 */
router.get('/:queue', function(req, res) {
  amqpConn.createChannel(function(err, ch) {
    d = new Date();
    var q = req.params.queue;
    /*      var msg = req.body.document;*/
    /*      var msg = d.getTime();*/
    var msg = "test";

    ch.assertQueue(q, {durable: config.amqp.queue_durable});
    // Note: on Node 6 Buffer.from(msg) should be used
    ch.sendToQueue(q, new Buffer(msg));
    console.log(" [x] Sent %s", msg);
  });
	res.json({ thishappened: 'GET queue executed'});
});


module.exports = router;
