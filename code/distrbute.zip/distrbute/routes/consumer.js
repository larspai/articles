var router = express.Router();
var amqp = require('amqplib/callback_api');
var http = require('http');
var DataTransform = require('node-json-transform').DataTransform;

/*
 * Create (POST) consumer.
 */
 router.post('/', function(req, res) {
  var db = req.db;
  var consumer = db.get('consumer');
  return consumer.insert({ name: req.body.name, description: req.body.description, queue: req.body.queue, binding: req.body.binding, routingkeys: req.body.routingkeys, pattern: req.body.pattern, transformer: req.body.transformer, template: req.body.template, endpoint: req.body.endpoint, autostart: req.body.autostart }, function(err,Cinserted){
  console.log('Consumer inserted: ' + Cinserted.name + " " + Cinserted._id);
  amqpConn.createChannel(function(err, ch) {
    if (closeOnErr(err)) return;
    ch.on("error", function(err) {
      console.error("[RMQ] channel error: ", err.message);
    });
    ch.on("close", function() {
      console.log("[RMQ] channel closed");
      removeConsumer(consumers,"distrbute_id",ch.distrbute_id);
    });

    ch.distrbute_name = req.body.name;
    ch.distrbute_queue = req.body.queue;
    ch.distrbute_id = Cinserted._id;
    var q = req.body.queue;
    var ex = req.body.binding;
    var options = JSON.parse('{"x-match":' + req.body.pattern + ', ' + req.body.routingkeys + '}');

    ch.assertExchange(ex, 'headers', {durable: config.amqp.exchange_durable});
    ch.prefetch(10);
    ch.assertQueue(q, { durable: config.amqp.queue_durable }, function(err, _ok) {
      if (closeOnErr(err)) return;
      ch.bindQueue(q, req.body.binding, '', options);
      ch.consume(q, processMsg, { noAck: true });
      consumers.push(ch);
      console.log("Consumer is started");
    });
    ch.template=Cinserted.template;
    function processMsg(msg) {
      consumeMsg(msg, ch, db);
    };
    function closeOnErr(err) {
      if (!err) return false;
      console.error("[RMQ] channel error: ", err);
      console.log("Closing...");
      ch.close();
      removeConsumer(consumers,"distrbute_id",ch.distrbute_id);
      return true;
    }
    res.json({ "result":"200","remarks": "POST consumer"});
    });
  });
});

/*
 * start consumer.
 */
 router.post('/:id/start', function(req, res) {
   console.log("Start: " + req.params.id);
   startConsumer(req.params.id, req.db, function(started){
    if(started){
       res.json({ "result":"200","remarks": "Start consumer"});
    } else {
      res.json({ error: 'No consumer found.'});
    }
  });
});

function startConsumer(consumerid, db, started) {
  removeQueue(queues,"distrbute_id",consumerid);
  var consumer = db.get('consumer');
  consumer.findOne({ _id:consumerid }, function(err,Cfound){
    if(!Cfound) {
      started(false);
    } else {
      amqpConn.createChannel(function(err, ch) {
        if (closeOnErr(err)) return;
        ch.on("error", function(err) {
          console.error("[RMQ] channel error (consumer): ", err.message);
        });
        ch.on("close", function() {
          console.log("[RMQ] channel closed");
          removeConsumer(consumers,"distrbute_id",ch.distrbute_id);
        });

        ch.distrbute_name = Cfound.name;
        ch.distrbute_queue = Cfound.queue;
        ch.distrbute_id = Cfound._id;
        ch.distrbute_transformer = Cfound.transformer;
        ch.template=Cfound.template;
        ch.endpoint=Cfound.endpoint;
        ch.distrbute_bound=1;

        var q = Cfound.queue;
        var ex = Cfound.binding;
        var options = JSON.parse('{"x-match":' + Cfound.pattern + ', ' + Cfound.routingkeys + '}');

        ch.assertExchange(ex, 'headers', {durable: config.amqp.exchange_durable});
      /*    ch.prefetch(10);*/
        ch.assertQueue(q, { durable: config.amqp.queue_durable }, function(err, _ok) {
          if (closeOnErr(err)) return;
          ch.bindQueue(q, ex, '', options);
          ch.consume(q, processMsg, { noAck: true });
          consumers.push(ch);
          var queue = {};
          queue.distrbute_id = ch.distrbute_id;
          queues.push(queue);
          console.log("Start; Consumer is started");
        });
        function processMsg(msg) {
          consumeMsg(msg, ch, db);
        };
        function closeOnErr(err) {
          if (!err) return false;
          console.error("[RMQ] channel error: ", err);
          console.log("Closing channel (consumer): " + ch.distrbute_name + ", " + ch.distrbute_id);
          ch.close();
          removeConsumer(consumers,"distrbute_id",ch.distrbute_id);
        }
        started(true);
      });
    }
  });
};

function consumeMsg(msg, ch, db){
  var success = false;
  status = "OK";
  try {
    eval('var data ='+msg.content);
    eval('var map ='+ch.template);
    if(ch.distrbute_transformer=="Object"){
      var dataTransform = DataTransform({parent:[data]}, map);
    } else {
      var dataTransform = DataTransform(data, map);
    }
    var result = dataTransform.transform();
    success = true;
  } catch(err) {
    result = err.message;
    status = "Error";
    success = false;
  }
//  console.log("Transformation:");
//  console.log(result);
  if(success){
    deliverMessage(result, ch.endpoint, function(destres){
      d = new Date();
      var msglog = db.get('msglog');
      msglog.insert({ deliverypoint: "4", timestamp: d.getTime(), msg_id: msg.properties.correlationId, transaction_id: msg.properties.messageId, ext_msg_id: "", source: ch.endpoint, destination: ch.distrbute_name, routingkeys: "-", headers: destres.headers, body: destres.body, status: destres.status, flow: "Consumer", user: ch.distrbute_name }, function(err,Cinserted){
      });
    });
  }
  logMsg(msg, ch, db, result);
/*  console.log(msg);*/
}

function logMsg(msg, ch, db, result){
  d = new Date();
  var msglog = db.get('msglog');
  msglog.insert({ deliverypoint: "3", timestamp: d.getTime(), msg_id: msg.properties.correlationId, transaction_id: msg.properties.messageId, ext_msg_id: "", source: ch.distrbute_queue, destination: ch.endpoint, routingkeys: JSON.stringify(msg.properties.headers), headers: msg.properties.headers, body: JSON.stringify(result), status: status, flow: "Consumer", user: ch.distrbute_name }, function(err,Cinserted){
  });
  return;
};

/*
 * sample/test endpoint.
 */
router.post('/sampleendpoint', function(req, res) {
  console.log("sampleendpoint: ");
  console.log(req.rawBody.toString());
  res.json({"remarks": "JSON message received. Length: " + req.rawBody.length});
});

function deliverMessage(message, url, destres) {
  var data = JSON.stringify(message);
  var port = 80;
  var inserted = 0;
  var Path = "";
  var Host = url.toLowerCase();
  if(Host.search("https://")>0){http = require('https'); port = 443;}
  Host = Host.replace("http://","");
  Host = Host.replace("https://","");
  if(Host.search("/")>0){
    Path = Host.substr(Host.search("/"));
    Host = Host.substring(0,Host.search("/"));
  } else {
    Path = "/";
  }
  if(Host.search(":")>0){
    port = Host.substr(Host.search(":")+1);
    Host = Host.substring(0,Host.search(":"));
  }
  var options = {
    host: Host,
    port: port,
    path: Path,
    method: 'POST',
    headers: {
      'Content-Type': 'application/json; charset=utf-8',
      'Content-Length': data.length
    }
  };
  var req2 = http.request(options, function(res2) {
    var returnObj = {};
    var returnHeaders = '';
    var msg = '';
    res2.setEncoding('utf8');
    res2.on('data', function(chunk) {
      msg += chunk;
    });
    res2.on('end', function() {
      returnObj.status = res2.statusCode;
      for(var item in res2.headers) {
        returnHeaders = returnHeaders + item + ": " + res2.headers[item] + "\n";
      }
      returnObj.headers = returnHeaders;
      returnObj.body = msg;
      //destres(JSON.parse(msg));
      destres(returnObj);
    });
    res2.on('error', function(error) {
      console.log("Error occurred: " + error);
    });
  });
  req2.write(data);
  req2.end();
}

/*
 * stop consumer
 */
 router.post('/:id/stop', function(req, res) {
   console.log("stop: " + req.params.id);
   stopConsumer(req.params.id, req.db, function(stopped){
    if(stopped){
       res.json({ "result":"200","remarks": "Start consumer"});
    } else {
      res.json({ error: 'No consumer found.'});
    }
  });
   res.json({ "result":"200","remarks": "Consumer stopped"});
 });

function stopConsumer(consumerid, db, stopped) {
  var consumer = db.get('consumer');
  consumer.findOne({ _id:consumerid }, function(err,Cfound){
    if(!Cfound) {
      stopped(false);
    } else {
      var q = Cfound.queue;
      var ex = Cfound.binding;
      var options = JSON.parse('{"x-match":' + Cfound.pattern + ', ' + Cfound.routingkeys + '}');
      ch=findConsumer(consumers, "distrbute_id", consumerid);
      if(ch.length == 1) {
//        ch[0].unbindQueue(q, ex, '', options);
        ch[0].close();
        stopped(true);
      }
    }
  });
}

/*
 * unbind consumer
 */
 router.post('/:id/unbind', function(req, res) {
   console.log("unbind: " + req.params.id);
   unbindConsumer(req.params.id, req.db, function(unbound){
     if(unbound){
       res.json({ "result":"200","remarks": "Consumer unbound"});
     } else {
      res.json({ error: 'No consumer found.'});
      }
    });
  });

function unbindConsumer(consumerid, db, unbound) {
  var consumer = db.get('consumer');
  consumer.findOne({ _id:consumerid }, function(err,Cfound){
    if(!Cfound) {
      unbound(false);
    } else {
      var q = Cfound.queue;
      var ex = Cfound.binding;
      var options = JSON.parse('{"x-match":' + Cfound.pattern + ', ' + Cfound.routingkeys + '}');
      ch=findConsumer(consumers, "distrbute_id", consumerid);
      if(ch.length == 1) {
        ch[0].unbindQueue(q, ex, '', options);
        unbound(true);
        ch[0].distrbute_bound = 0;
        removeQueue(queues,"distrbute_id",ch[0].distrbute_id);
      }
    }
  });
}

/*
 * Update (PUT) consumer.
 */
router.put('/:id', function(req, res) {
    var db = req.db;
    var consumer = db.get('consumer');
		consumer.updateById( req.params.id, { $set: { name: req.body.name, description: req.body.description, queue: req.body.queue, binding: req.body.binding, routingkeys: req.body.routingkeys, pattern: req.body.pattern, transformer: req.body.transformer, template: req.body.template, endpoint: req.body.endpoint, autostart: req.body.autostart }}, function(err,consumerupdated){
      console.log('Consumer updated: ' + req.params.id + ", " + req.body.name);
			res.json(consumerupdated.ok);
		});
});

/*
 * Delete (DELETE) consumer.
 */
router.delete('/:id', function(req, res) {
    var db = req.db;
    var consumer = db.get('consumer');
		consumer.remove({ "_id": req.params.id}, function(err){
			if(err){res.send(err)} else {
        var before = consumers.length;
        for (j = 0; j < consumers.length; j++) {
          if(consumers[j].distrbute_id = req.params.id) {
            consumers[j].close();
          }
        }
        removeConsumer(consumers,"distrbute_id",req.params.id);
        after = consumers.length;
        res.json({"Deleted":before-after});
      }
		});
});


/*
 * Get (GET) consumer.
 */
router.get('/', function(req, res) {
    var db = req.db;
    var consumer = db.get('consumer');
    consumer.find({ }, function(err, foundC) {
      if(!foundC) {
      	res.json({ error: 'No consumer found.'});
      } else {
        for (j = 0; j < foundC.length; j++) {
          var foundConsumer=findConsumer(consumers, "distrbute_id", foundC[j]._id.toString());
          if(foundConsumer.length > 0) {
            foundC[j].started = 1;
          } else {foundC[j].bound = 0;};
          var foundQueue=findQueue(queues, "distrbute_id", foundC[j]._id.toString());
          foundC[j].bound = foundQueue.length;
        }
        res.json(foundC);
      }
    });
    console.log(listcons());
});

function listcons(){
var text = "Consumers(" + consumers.length + "), Queues("+ queues.length + "):\n";
for (j = 0; j < consumers.length; j++) {
  text = text + "id: " + consumers[j].distrbute_id + ", bound: " + consumers[j].distrbute_bound + ", name: " + consumers[j].distrbute_name + "\n";
}
for (j = 0; j < queues.length; j++) {
  text = text + "q id: " + queues[j].distrbute_id + "\n";
}
  return text;
};

function findConsumer (myObjects,prop,valu) {
  existConsumer = myObjects.filter(function (val) {
    return val[prop] == valu;
  });
  return existConsumer;
}

function removeConsumer (myObjects,prop,valu) {
  consumers = myObjects.filter(function (val) {
    return val[prop] != valu;
  });
}

function findQueue (myObjects,prop,valu) {
  existQueue = myObjects.filter(function (val) {
    return val[prop] == valu;
  });
  return existQueue;
}

function removeQueue (myObjects,prop,valu) {
  queues = myObjects.filter(function (val) {
    return val[prop] != valu;
  });
}

/*
 * start all consumers.
 */
 router.get('/startall', function(req, res) {
   console.log("Start all consumers");
   startConsumers(req);
});

function startConsumers(req) {
  var db = req.db;
  var consumer = db.get('consumer');
  consumer.find({ }, function(err, foundC) {
    if(!foundC) {
    	console.log('No consumer found.');
    } else {
      for (j = 0; j < foundC.length; j++) {
        if(foundC[j].autostart=="yes"){
          startConsumer(foundC[j]._id.toString(), db, function(started){
            if(started){
              console.log("Started consumer");
            } else {
              console.log("Start consumer failed");
            }
          });
        }
      }
    }
  });
}


module.exports = router;
