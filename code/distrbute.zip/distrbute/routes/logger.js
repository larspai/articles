var amqp = require('amqplib/callback_api');
var router = express.Router();

router.logger = function startLogger(db){
  amqpConn.createChannel(function(err, ch) {
    if (closeOnErr(err)) return;
    ch.on("error", function(err) {
      console.error("[RMQ] channel error (logger): ", err.message);
    });
    ch.on("close", function() {
      console.log("[RMQ] channel closed");
    });

    var q = "firehose-logging";
    var ex = "amq.rabbitmq.trace";

    ch.assertExchange(ex, 'topic', {durable: true, internal: true});
    ch.assertQueue(q, { durable: true }, function(err, _ok) {
      if (closeOnErr(err)) return;
      ch.bindQueue(q, ex, '#');
      ch.consume(q, processMsg, { noAck: true });
      console.log("Start; logging started");
    });
    function processMsg(msg) {
      consumeMsg(msg, ch, db);
    };
    function closeOnErr(err) {
      if (!err) return false;
      console.error("[RMQ] channel error: ", err);
      console.log("Closing channel (logger)");
      ch.close();
    }
  });
};

function consumeMsg(msg, ch, db){
  d = new Date();
  var msglog = db.get('msglog');
  exctxt = msg.fields.routingKey.indexOf("publish");
  deliverypoint = (exctxt==-1)?"2":"1";
  msglog.insert({ deliverypoint: deliverypoint, timestamp: d.getTime(), msg_id: msg.properties.headers.properties.correlation_id, transaction_id: msg.properties.headers.properties.message_id, ext_msg_id: "", source: msg.properties.headers.exchange_name, destination: msg.fields.routingKey.substr(8), routingkeys: msg.fields.routingKey, headers: msg.properties.headers.properties.headers, body: msg.content.toString(), status: "", flow: "Logger", user: msg.properties.headers.user }, function(err,Cinserted){
    console.log('Message inserted (logger): ' + Cinserted._id);
  });
};

/*
 * Get (GET) log.
 */
router.get('/', function(req, res) {
    var filter = JSON.parse('{"sort": { "msg_id" : -1, "transaction_id" : -1, "deliverypoint" : 1 }, "limit": 50}');
    var db = req.db;
    var msglog = db.get('msglog');
//    msglog.find({  },{ sort : { msg_id : -1, transaction_id : -1, deliverypoint : 1 }, limit: 50 }, function(err, foundC) {
    msglog.find({  },filter, function(err, foundC) {
      if(!foundC) {
      	res.json({ error: 'No transactions found.'});
      } else {
        res.json(foundC);
      }
    });
    //res.json(msglog.find().sort({timestamp:1}));
});

module.exports = router;
