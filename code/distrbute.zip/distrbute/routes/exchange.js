var router = express.Router();
var amqp = require('amqplib/callback_api');

/*
 * Update (POST) exchange.
 */
router.post('/:exchange', function(req, res) {
  /*console.log(req);*/
  var instring = req.headers.routing_keys.toString();
  var keyvals = instring.split(",");
  var str = new Object();
  for (var i = 0; i < keyvals.length; i++) {
    var keyval = keyvals[i].split(":");
    str[keyval[0]] = keyval[1];
  }
  var rheaders = new Object({'headers': str});
  rheaders['correlationId'] = uuid();
  console.log(rheaders);
  var ex = req.params.exchange;
  amqpConn.createChannel(function(err, ch) {
    ch.assertExchange(ex, 'headers', {durable: config.amqp.exchange_durable});
/*    ch.publish(ex, '', req.rawBody,{headers: {'baz': 'boo'}});*/
    ch.publish(ex, '', req.rawBody, rheaders);
  });
	res.json({ thishappened: 'POST exchange executed'});
});

/*
* Create an ID
*/
function uuidv4() {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
}

function uuid() {
  d = new Date();
  return 'A' + d.getTime();
}

/*
 * Update (GET) exchange.
 */
router.get('/:exchange', function(req, res) {
  amqpConn.createChannel(function(err, ch) {
    var ex = req.params.exchange;
    var msg = "test";

    ch.assertExchange(ex, 'header', {durable: config.amqp.exchange_durable});
    // Note: on Node 6 Buffer.from(msg) should be used
    ch.publish(ex, 'test',new Buffer(msg));
    console.log(" [x] Sent %s", msg);
  });
	res.json({ thishappened: 'GET exchange executed'});
});


module.exports = router;
