express = require('express')
var session = require('express-session');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var path = require('path');
//var mongo = require('mongodb');
var monk = require('monk');

config = require('./globals.json');
var db = monk(config.mongo.MONGO_URI);

var app = express();

var amqp = require('amqplib/callback_api');
amqpConn = null;

var rawBodySaver = function(req, res, buf, encoding) {
    req.rawBody = buf;
  }
app.use(bodyParser.json({ verify: rawBodySaver }));
app.use(bodyParser.urlencoded({ verify: rawBodySaver, extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

var routes = require('./routes/index');
var queue = require('./routes/queue');
var exchange = require('./routes/exchange');
var dummy = require('./routes/dummy');
var consumer = require('./routes/consumer');
var logger = require('./routes/logger');

// Make our db accessible to our router
app.use(function(req, res, next) {
    req.db = db;
    next();
});

app.use('/', routes);
app.use('/queue', queue);
app.use('/exchange', exchange);
app.use('/dummy', dummy);
app.use('/consumer', consumer);
app.use('/logger', logger);

start();

consumers = new Array();
queues = new Array();

app.listen(config.server.HTTPPort, function () {
  console.log('Listening on port ' + config.server.HTTPPort +  ' (' + config.mongo.MONGO_URI + ')')
});

function start() {
  amqp.connect(config.amqp.AMQP_URI + "?heartbeat=60", function(err, conn) {
    if (err) {
      console.error("[RMQ]", err.message);
      return setTimeout(start, 1000);
    }
    conn.on("error", function(err) {
      if (err.message !== "Connection closing") {
        console.error("[RMQ] conn error: ", err.message);
      }
    });
    conn.on("close", function() {
      console.error("[RMQ] Reconnecting");
      return setTimeout(start, 1000);
    });
    console.log("[RMQ] Connected");
    amqpConn = conn;
    dispatchToRouter(consumer, '/startall', function(results){
      console.log(results);
    });
    logger.logger(db);
/*    whenConnected();*/
  });
}

/**
* @param {express.Router} router
*/
function dispatchToRouter(router, url, callback) {

    var request = {
        url  : url,
        method : 'GET',
        db  : db
    };
    // stub a Response object with a (relevant) subset of the needed
    // methods, such as .json(), .status(), .send(), .end(), ...
    var response = {
        json : function(results) {
            callback(results);
        }
    };

    router.handle(request, response, function(err) {
        console.log('These errors happened during processing: ', err);
    });
}
